[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/2rGsAIMQ)
# COE2SH4-PPA3Template
Project Preparation Activity 3

You must watch the briefing video and read through the manual to engage in the development activities.


Section: L02

MacID: hee6

StudentID: 400449140
