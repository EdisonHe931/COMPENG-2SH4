#ifndef MY_STRLIB
#define MY_STRLIB

// Same contents from Lab 3 Q1 prototypes.
int my_strlen(const char * const str1);
int my_strcmp(const char * const str1, const char * const str2);
int my_strcmpOrder(const char * const str1, const char * const str2);
char *my_strcat(const char * const str1, const char * const str2);

#endif