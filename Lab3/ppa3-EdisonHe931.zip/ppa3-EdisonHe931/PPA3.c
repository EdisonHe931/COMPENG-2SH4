#include <stdio.h>
#include <time.h>
#include "MacUILib.h"
#include "myStringLib.h"   // This is your first custom C library

// [TODO] Import the required library for rand() and srand()
// [TODO] Import the required library for accessing the current time - for seeding random number generation





// PREPROCESSOR DIRECTIVE CONSTANTS
// ================================
// For program-wide constants, define them here using #define.  Add as seen needed.

// [COPY AND PASTE FROM PPA2] Copy your additional preprocessor constants from PPA2 and paste them below


// [TODO] Then, define more constants here as seen needed.





// GLOBAL VARIABLES
// ================================

int exitFlag; // Program Exiting Flag

// [COPY AND PASTE FROM PPA2] Copy your additional global from PPA2 and paste them below
enum state{STILL,UP, DOWN, LEFT, RIGHT};
enum state direction;
char input;
char string[] = "McMaster-ECE";
char gameboard[10][20];
int delay,speed, moveCount, xRange, yRange, listSize, stop;
char* mysteryString;
struct objPos* itemBin;
// [TODO] : Define objPos structure here as described in the lab document
struct objPos 
{
    int x;
    int y;
    char symbol;
}obj;

// [TODO] Declare More Global Variables as seen needed.

// [TODO] Declare Global Pointers as seen needed / instructed in the manual.








// FUNCTION PROTOTYPES
// ================================
// Declare function prototypes here, so that we can organize the function implementation after the main function for code readability.

void Initialize(void);
void GetInput(void);
void RunLogic(void);
void DrawScreen(void);
void LoopDelay(void);
void CleanUp(void);

// [TODO] In PPA3, you will need to implement this function to generate random items on the game board
//        to set the stage for the Scavenger Hunter game.
// list[]       The pointer to the Item Bin
// listSize     The size of the Item Bin (5 by default)
// playerPos    The pointer to the Player Object, read only.
// xRange       The maximum range for x-coordinate generation (probably the x-dimension of the gameboard?)
// yRange       The maximum range for y-coordinate generation (probably the y-dimension of the gameboard?)
// str          The pointer to the start of the Goal String (to choose the random characters from)
void GenerateItems(struct objPos list[], const int listSize, const struct objPos *obj, const int xRange, const int yRange, const char* str);




// MAIN PROGRAM
// ===============================
int main(void)
{

    Initialize();

    while(!exitFlag)  
    {
        GetInput();

        RunLogic();

        DrawScreen();

        LoopDelay();
    }

    CleanUp();

}




// INITIALIZATION ROUTINE
// ===============================
void Initialize(void)
{
    MacUILib_init();

    MacUILib_clearScreen();

    // [COPY AND PASTE FROM PPA2] Copy your initialization routine from PPA2 and paste them below
    srand(time(NULL));
    input = 0; // NULL
    stop = 0;
    exitFlag = 0;  // not exiting    
    delay = 100000;
    speed = 3;
    moveCount = 0;
    xRange = 18;
    yRange = 8;
    listSize = 5;
    // [TODO] : Initialize more variables here as seen needed.
    //          PARTICULARLY for the structs!!
    obj.x = 10;
    obj.y = 5;
    obj.symbol = '^';
    direction = STILL;
    int i,j;
    mysteryString = calloc(12,sizeof(char));
    for(i = 0; i < 12; i++)
    {
        mysteryString[i] = '?';
    }
    itemBin = calloc(5,sizeof(struct objPos));
    for(i = 0; i < 10;i++)
    {
        for(j =0;j<20;j++)
        if(i == 0 || i == 9)
        {
            gameboard[i][j] = '#';
        }
        else
        {
            if(j == 0 || j == 19)
            {
                gameboard[i][j] = '#';
            }
            else
            {
                gameboard[i][j] = ' ';
            }
        }

    }
    
    GenerateItems(itemBin, listSize, &obj, xRange,  yRange, string);
    // [TODO] Initialize any global variables as required.

    
    // [TODO] Allocated heap memory for on-demand variables as required.  Initialize them as required.

    // [TODO] Seed the random integer generation function with current time.

    // [TODO] Generate the initial random items on the game board at the start of the game.

    
}




// INPUT COLLECTION ROUTINE
// ===============================
void GetInput(void)
{

    // Asynchronous Input - non blocking character read-in
    
    // [COPY AND PASTE FROM PPA2] Copy your input collection routine from PPA2 and paste them below
    if(MacUILib_hasChar() && MacUILib_hasChar() != 9)
        {
            input = MacUILib_getChar();
        }
    // [TODO] Though optional for PPA3, you may insert any additional logic for input processing.

   
}




// MAIN LOGIC ROUTINE
// ===============================
void RunLogic(void)
{
    // [COPY AND PASTE FROM PPA2] Copy your main logic routine from PPA2 and paste them below
    gameboard[obj.y][obj.x] = ' ';
    
    if(input != 0)  // if not null character
    {
        switch(input)
        {                      
            case ' ':  // exit
                exitFlag = 1;
                break;
            
            // Add more key processing here
            // Add more key processing here
            // Add more key processing here    


            default:
                break;
        }
        
    }
    if(stop != 1){
        switch(input)
        {
            case 'w':
                if(direction != DOWN)
                {
                    direction = UP;
                    obj.symbol = '^';
                }
                break;
            case 'a':
                if(direction != RIGHT)
                {
                    direction = LEFT;
                    obj.symbol = '<';
                }
                break;
            case 's':
                if(direction != UP)
                {
                    direction = DOWN;
                    obj.symbol = 'v';
                }
                break;
            case 'd':
                if(direction != LEFT)
                {
                    direction = RIGHT;
                    obj.symbol = '>';
                }
                break;
            case '1':
                delay = 200000;
                speed = 1;
                break;
            case '2':
                delay = 150000;
                speed = 2;
                break;
            case '3':
                delay = 100000;
                speed = 3;
                break;
            case '4':
                delay = 75000;
                speed = 4;
                break;
            case '5':
                delay = 50000;
                speed = 5;
                break;
            default:
                break;
        }
        switch(direction)
        {
            case UP:
                obj.y--;
                
                break;
            case DOWN:
                obj.y++;
                
                break;
            case LEFT:
                obj.x--;
                
                break;
            case RIGHT:
                obj.x++;
                
                break;
            default:
                    break;
        }
        if(direction != STILL)
        {
            moveCount++;
        }
        input = 0; 
    }
    if(obj.y < 1) obj.y = 8;
    else if(obj.y > 8) obj.y = 1;
    else if(obj.x < 1) obj.x = 18;
    else if(obj.x > 18) obj.x = 1;

    gameboard[obj.y][obj.x] = obj.symbol;
    int i;
    for(i = 0; i < 5; i++)
    {
        gameboard[itemBin[i].y][itemBin[i].x] = itemBin[i].symbol;
    }

    
    // [TODO]   Implement the Object Collision logic here
    //
    //      Simple Collision Algorithm
    //      1. Go through all items on board and check their (x,y) against the player object x and y.
    //      2. If a match is found, use the ASCII symbol of the collided character, and 
    //         find all the occurrences of this ASCII symbol in the Goal String
    //      3. For every occurrence, reveal its ASCII character at the corresponding location in the
    //         Collected String
    //      4. Then, determine whether the game winning condition is met.
    int j,k;
    for ( i = 0; i < listSize; i++)
    {
        if (obj.x == itemBin[i].x && obj.y == itemBin[i].y )
        {
            for(j = 0; j < 12; j++)
            {
                if(itemBin[i].symbol == string[j])
                {
                    mysteryString[j] = itemBin[i].symbol;

                }
                
            }

            for ( k = 0; k < listSize; k++)
            {
                gameboard[itemBin[k].y][itemBin[k].x] = ' ';
            }
            
            
            GenerateItems(itemBin, listSize, &obj, xRange,  yRange, string);
            
            break;
        }
        
    }
    if(my_strcmpOrder(mysteryString,string) == -1)
        {
            stop = 1;
        }
    
    
    

    // [TODO]   Implement Game Winning Check logic here
    //
    //      Game Winning Check Algorithm
    //      1. Check if the contents of the Collected String exactly matches that of the Goal String.
    //         YOU MUST USE YOUR OWN my_strcmp() function from Lab 3.
    //      2. If matched, end the game.
    //      3. Otherwise, discard the current items on the game board, and 
    //         generate a new set of random items on the board.  Game continues.
    
}



// DRAW ROUTINE
// ===============================
void DrawScreen(void)
{
       
    // [COPY AND PASTE FROM PPA2] Copy your draw logic routine from PPA2 and paste them below
    MacUILib_clearScreen();
    int i,j;
    for(i = 0; i < 10; i++)
    {
        for(j = 0; j < 20;j++)
        {
            MacUILib_printf("%c",gameboard[i][j]);
        }
        MacUILib_printf("\n");
    }
    MacUILib_printf("Speed: %d\tMystery String: %s\n",speed, mysteryString);
    
    if(stop == 1){
        MacUILib_printf("\nYou Win! It took %d steps!",moveCount);
    }
    else
    {
        MacUILib_printf("Steps: %d", moveCount);
    }
    
    
    
    
    // [TODO]   Insert somewhere in the draw routine to draw the randomly generated items on the board.

    // [TODO]   Display the "Mystery String" contents at the bottom of the game board
    //          To help players keep track of their game progress.
    
    
    
}


// DELAY ROUTINE
// ===============================
void LoopDelay(void)
{
    MacUILib_Delay(delay); // 0.1s delay
}





// TEAR-DOWN ROUTINE
// ===============================
void CleanUp(void)
{
    // [TODO]   To prevent memory leak, free() any allocated heap memory here
    //          Based on the PPA3 requirements, you need to at least deallocate one heap variable here.

    // Insert any additional end-game actions here.
    

    MacUILib_uninit();
    free(mysteryString);
    free(itemBin);
}




// The Item Generation Routine
////////////////////////////////////
void GenerateItems(struct objPos list[], const int listSize, const struct objPos *obj, const int xRange, const int yRange, const char* str)
{
    char characters[10] = {'M','c','a','s','t','E','r','-','C', 'e'};
    
    int i;
    int change;
    
    for(i = 0; i < 5; i++)
    {
        change = 1;
        while(change == 1)
        {
            change = 0;
            list[i].x = (rand() %(xRange-1)) + 1;
            list[i].y = (rand() % (yRange-1)) + 1;

            if(i > 2){
                list[i].symbol = (rand()%126) + 33;
            }
            else
            {   
                list[i].symbol = characters[rand()%10];
            }
            


            if(list[i].y == obj->y && list[i].x == obj->x)
            {
                change = 1;
                break;
            }

            int j;
            for ( j = 0; j < i; j++)
            {
                if (list[i].y == list[j].y && list[i].x == list[j].x)
                {
                    change = 1;
                    break;
                }
                else if(list[i].symbol == list[j].symbol || list[i].symbol == 35|| list[i].symbol == 42|| list[i].symbol == 35
                 || list[i].symbol == 60 || list[i].symbol == 62 || list[i].symbol == 94 || list[i].symbol == 118|| list[i].symbol == 86)
                {
                    change = 1;
                    break;
                }   
            }
        }
    }
    
    // This is possibly one of the most conceptually challenging function in all PPAs
    // Once you've mastered this one, you are ready to take on the 2SH4 course project!

    // Random Non-Repeating Item Generation Algorithm
    ////////////////////////////////////////////////////

    // Use random number generator function, rand(), to generate a random x-y coordinate and a random choice of character from the Goal String as the ASCII character symbol.
    //      The x and y coordinate range should fall within the xRange and yRange limits, which should be the x- and y-dimension of the board size.
    // This will then be a candidate of the randomly generated Item to be placed on the game board.

    // In order to make sure this candidate is validated, it needs to meet both criteria below:
    //  1. Its coordinate and symbol has not been previously generated (no repeating item)
    //  2. Its coordinate does not overlap the Player's position
    // Thus, for every generated item candidate, check whether its x-y coordinate and symbol has previously generated.  
    //  Also, check if it overlaps the player position
    //      If yes, discard this candidate and regenerate a new one
    //      If no, this candidate is validated.  Add it to the input list[]

    // There are many efficient ways to do this question
    //  We will take a deep dive into some methods in 2SI.

}
